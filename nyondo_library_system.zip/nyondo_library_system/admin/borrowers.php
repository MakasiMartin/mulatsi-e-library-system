<?php
require '../config.php';
require_role('admin');
$sql = "SELECT u.*, COUNT(l.id) AS active_loans
        FROM users u LEFT JOIN loans l ON l.user_id = u.id AND l.status = 'borrowed'
        WHERE u.role = 'student' GROUP BY u.id ORDER BY u.name";
$rows = $pdo->query($sql)->fetchAll();
$page_title = 'Borrowers';
$base_path = '../';
require '../includes/header.php';
?>
<h1>Borrowers</h1>
<div class="admin-layout">
<?php require '_nav.php'; ?>
<section class="table-wrap"><table>
<tr><th>Student</th><th>Student No.</th><th>Class</th><th>Contact / Email</th><th>Books borrowed</th></tr>
<?php foreach ($rows as $row): ?>
<tr><td><?= e($row['name']) ?></td><td><?= e($row['student_no']) ?></td><td><?= e($row['class_name']) ?></td><td><?= e($row['email']) ?></td><td><?= (int)$row['active_loans'] ?></td></tr>
<?php endforeach; ?>
</table></section></div>
<?php require '../includes/footer.php'; ?>
