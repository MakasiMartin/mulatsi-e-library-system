<?php
require '../config.php';
require_role('admin');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'issue') {
    $userId = (int)($_POST['user_id'] ?? 0);
    $bookId = (int)($_POST['book_id'] ?? 0);
    $dueDate = $_POST['due_date'] ?? '';
    try {
        $pdo->beginTransaction();
        $stmt = $pdo->prepare('SELECT available_copies FROM books WHERE id = ? FOR UPDATE');
        $stmt->execute([$bookId]);
        $book = $stmt->fetch();
        if (!$book || (int)$book['available_copies'] < 1) {
            throw new Exception('No copies of this book are currently available.');
        }
        $stmt = $pdo->prepare("INSERT INTO loans (user_id, book_id, issue_date, due_date, status) VALUES (?, ?, CURDATE(), ?, 'borrowed')");
        $stmt->execute([$userId, $bookId, $dueDate]);
        $stmt = $pdo->prepare('UPDATE books SET available_copies = available_copies - 1 WHERE id = ?');
        $stmt->execute([$bookId]);
        $pdo->commit();
        flash('success', 'Book issued successfully.');
    } catch (Throwable $ex) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('error', $ex->getMessage());
    }
    redirect('loans.php');
}

if (isset($_GET['return'])) {
    $loanId = (int)$_GET['return'];
    try {
        $pdo->beginTransaction();
        $stmt = $pdo->prepare("SELECT book_id FROM loans WHERE id = ? AND status = 'borrowed' FOR UPDATE");
        $stmt->execute([$loanId]);
        $loan = $stmt->fetch();
        if ($loan) {
            $stmt = $pdo->prepare("UPDATE loans SET status = 'returned', return_date = CURDATE() WHERE id = ?");
            $stmt->execute([$loanId]);
            $stmt = $pdo->prepare('UPDATE books SET available_copies = available_copies + 1 WHERE id = ?');
            $stmt->execute([(int)$loan['book_id']]);
        }
        $pdo->commit();
        flash('success', 'Return recorded.');
    } catch (Throwable $ex) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('error', 'Could not record return.');
    }
    redirect('loans.php');
}

$students = $pdo->query("SELECT id, name, student_no FROM users WHERE role = 'student' AND status = 'active' ORDER BY name")->fetchAll();
$books = $pdo->query('SELECT id, title, available_copies FROM books WHERE available_copies > 0 ORDER BY title')->fetchAll();
$loans = $pdo->query('SELECT l.*, u.name, u.student_no, b.title FROM loans l JOIN users u ON u.id = l.user_id JOIN books b ON b.id = l.book_id ORDER BY l.id DESC')->fetchAll();
$page_title = 'Borrowed Books';
$base_path = '../';
require '../includes/header.php';
?>
<h1>Borrowed Books</h1>
<div class="admin-layout">
<?php require '_nav.php'; ?>
<section>
<div class="panel"><h3>Issue a book</h3>
<form method="post"><input type="hidden" name="action" value="issue">
<div class="form-row"><div><label>Student</label><select name="user_id" required><option value="">Select student</option>
<?php foreach ($students as $student): ?><option value="<?= (int)$student['id'] ?>"><?= e($student['name'] . ' · ' . $student['student_no']) ?></option><?php endforeach; ?>
</select></div><div><label>Book</label><select name="book_id" required><option value="">Select book</option>
<?php foreach ($books as $book): ?><option value="<?= (int)$book['id'] ?>"><?= e($book['title'] . ' · ' . $book['available_copies'] . ' available') ?></option><?php endforeach; ?>
</select></div><div><label>Due date</label><input type="date" name="due_date" min="<?= date('Y-m-d') ?>" required value="<?= date('Y-m-d', strtotime('+14 days')) ?>"></div></div>
<button class="btn" style="margin-top:15px">Issue book</button></form></div>
<h3>Borrowing records</h3><div class="table-wrap"><table>
<tr><th>Student</th><th>Book</th><th>Issue date</th><th>Due date</th><th>Return date</th><th>Status</th><th>Action</th></tr>
<?php foreach ($loans as $item): ?><tr>
<td><?= e($item['name'] . ' (' . $item['student_no'] . ')') ?></td><td><?= e($item['title']) ?></td><td><?= e($item['issue_date']) ?></td><td><?= e($item['due_date']) ?></td><td><?= e($item['return_date'] ?? '—') ?></td><td><?= e($item['status']) ?></td>
<td><?php if ($item['status'] === 'borrowed'): ?><a class="btn small" data-confirm="Record this book as returned?" href="?return=<?= (int)$item['id'] ?>">Return</a><?php else: ?>—<?php endif; ?></td>
</tr><?php endforeach; ?>
</table></div></section></div>
<?php require '../includes/footer.php'; ?>
