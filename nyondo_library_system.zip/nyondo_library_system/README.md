# NYONDO SS Library Management System

## Requirements
- XAMPP (Apache + MySQL)
- PHP 8.0+ (PDO MySQL extension enabled)
- A modern browser

## Installation
1. Extract `nyondo_library_system.zip`.
2. Copy the `nyondo_library_system` folder into `C:\xampp\htdocs\`.
3. Open XAMPP Control Panel and start **Apache** and **MySQL**.
4. Visit `http://localhost/phpmyadmin`.
5. Choose **Import**, select `database.sql` from the project folder, and import it.
6. If your MySQL root account has a password, update `$pass` in `config.php`.
7. Open `http://localhost/nyondo_library_system/`.

## First administrator login
- Email: `admin@nyondo.local`
- Password: `password`

Change the administrator password before using this system with real student data. The demo password is provided only for local development.

## Main pages
- `index.php` — public homepage
- `about.php` — about the library
- `books.php` — public book catalogue and search
- `register.php` — student registration
- `login.php` — student login
- `login.php?role=admin` — administrator login
- `admin/dashboard.php` — administrator dashboard
- `admin/books.php` — add, edit and delete books
- `admin/users.php` — activate/deactivate student accounts
- `admin/borrowers.php` — borrower listing
- `admin/loans.php` — issue and return books
- `student/dashboard.php` — student's borrowing history

## Notes
- The project uses PDO prepared statements and password hashing.
- Book issue/return updates are wrapped in database transactions.
- This is a working starter implementation. Before public deployment, add HTTPS, CSRF tokens, stronger account recovery, audit logging, backups, and a formal privacy policy.
- The school crest in the header is a text-based placeholder. Replace it with your authorised school logo in the header if available.
