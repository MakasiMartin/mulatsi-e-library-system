<?php
require 'config.php';
$role = ($_GET['role'] ?? '') === 'admin' ? 'admin' : 'student';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $email=trim($_POST['email']??''); $password=$_POST['password']??''; $wanted=$_POST['role']??'student';
  $stmt=$pdo->prepare("SELECT * FROM users WHERE email=? AND role=? AND status='active'"); $stmt->execute([$email,$wanted]); $u=$stmt->fetch();
  if ($u && password_verify($password,$u['password'])) {
    session_regenerate_id(true); $_SESSION['user_id']=$u['id']; $_SESSION['name']=$u['name']; $_SESSION['role']=$u['role'];
    redirect($u['role']==='admin'?'admin/dashboard.php':'student/dashboard.php');
  } else { flash('error','Invalid email, password or account type.'); redirect('login.php?role='.urlencode($wanted)); }
}
$page_title='Login';$base_path='';require 'includes/header.php'; ?>
<div class="auth-wrap"><div class="panel"><h2><?= $role==='admin'?'Admin Login':'Students Login' ?></h2><p class="muted">Enter your account details to continue.</p><form method="post">
<input type="hidden" name="role" value="<?= e($role) ?>">
<label>Email address</label><input type="email" name="email" required autocomplete="username">
<label>Password</label><input type="password" name="password" required autocomplete="current-password">
<button class="btn" style="margin-top:18px;width:100%">Login</button></form>
<p class="muted">Student without an account? <a href="register.php">Register here</a>.</p><p><a href="login.php?role=admin">Admin login</a> · <a href="login.php">Student login</a></p></div></div>
<?php require 'includes/footer.php'; ?>