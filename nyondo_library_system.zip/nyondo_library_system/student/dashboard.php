<?php
require '../config.php';
require_role('student');
$stmt = $pdo->prepare('SELECT l.*, b.title, b.author FROM loans l JOIN books b ON b.id = l.book_id WHERE l.user_id = ? ORDER BY l.id DESC');
$stmt->execute([$_SESSION['user_id']]);
$loans = $stmt->fetchAll();
$page_title = 'My Account';
$base_path = '../';
require '../includes/header.php';
?>
<h1>Welcome, <?= e($_SESSION['name']) ?></h1>
<div class="grid">
  <div class="card"><h3>My borrowed books</h3><p>Review books currently issued to you and their due dates.</p></div>
  <div class="card"><h3>Find a book</h3><p>Explore the school library catalogue.</p><a class="btn" href="../books.php">Browse books</a></div>
</div>
<h2 class="section">My borrowing history</h2>
<div class="table-wrap"><table>
<tr><th>Book</th><th>Author</th><th>Issue date</th><th>Due date</th><th>Return date</th><th>Status</th></tr>
<?php foreach ($loans as $loan): ?>
<tr>
<td><?= e($loan['title']) ?></td><td><?= e($loan['author']) ?></td>
<td><?= e($loan['issue_date']) ?></td><td><?= e($loan['due_date']) ?></td>
<td><?= e($loan['return_date'] ?? '—') ?></td><td><?= e($loan['status']) ?></td>
</tr>
<?php endforeach; ?>
</table></div>
<?php require '../includes/footer.php'; ?>
