CREATE DATABASE IF NOT EXISTS nyondo_library CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE nyondo_library;

CREATE TABLE IF NOT EXISTS users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 email VARCHAR(160) NOT NULL UNIQUE,
 password VARCHAR(255) NOT NULL,
 role ENUM('admin','student') NOT NULL DEFAULT 'student',
 student_no VARCHAR(60) NULL UNIQUE,
 class_name VARCHAR(60) NULL,
 status ENUM('active','inactive') NOT NULL DEFAULT 'active',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS books (
 id INT AUTO_INCREMENT PRIMARY KEY,
 title VARCHAR(180) NOT NULL,
 author VARCHAR(140) NOT NULL,
 category VARCHAR(100) DEFAULT '',
 isbn VARCHAR(50) DEFAULT '',
 total_copies INT NOT NULL DEFAULT 1,
 available_copies INT NOT NULL DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS borrowers (
 id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NOT NULL UNIQUE,
 registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS loans (
 id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NOT NULL,
 book_id INT NOT NULL,
 issue_date DATE NOT NULL,
 due_date DATE NOT NULL,
 return_date DATE NULL,
 status ENUM('borrowed','returned') NOT NULL DEFAULT 'borrowed',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (user_id) REFERENCES users(id),
 FOREIGN KEY (book_id) REFERENCES books(id)
) ENGINE=InnoDB;

-- Demo administrator. Password: password
-- Change this password immediately after first login.
INSERT INTO users(name,email,password,role)
SELECT 'Library Administrator','admin@nyondo.local',
'$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','admin'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email='admin@nyondo.local');

INSERT INTO books(title,author,category,isbn,total_copies,available_copies)
SELECT 'Test Book','Sample Author','General','DEMO-001',5,5
WHERE NOT EXISTS (SELECT 1 FROM books WHERE isbn='DEMO-001');
INSERT INTO books(title,author,category,isbn,total_copies,available_copies)
SELECT 'Clean Code','Robert C. Martin','Programming','DEMO-002',2,2
WHERE NOT EXISTS (SELECT 1 FROM books WHERE isbn='DEMO-002');
INSERT INTO books(title,author,category,isbn,total_copies,available_copies)
SELECT 'Code Complete','Steve McConnell','Programming','DEMO-003',2,2
WHERE NOT EXISTS (SELECT 1 FROM books WHERE isbn='DEMO-003');
INSERT INTO books(title,author,category,isbn,total_copies,available_copies)
SELECT 'The Pragmatic Programmer','Andrew Hunt and David Thomas','Programming','DEMO-004',2,2
WHERE NOT EXISTS (SELECT 1 FROM books WHERE isbn='DEMO-004');
