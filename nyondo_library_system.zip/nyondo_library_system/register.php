<?php
require 'config.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $name=trim($_POST['name']??'');$email=trim($_POST['email']??'');$student_no=trim($_POST['student_no']??'');$class=trim($_POST['class']??'');$password=$_POST['password']??'';
 if(!$name||!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($password)<6){flash('error','Enter valid details. Password must be at least 6 characters.');redirect('register.php');}
 try{$s=$pdo->prepare("INSERT INTO users(name,email,password,role,student_no,class_name) VALUES(?,?,?,'student',?,?)");$s->execute([$name,$email,password_hash($password,PASSWORD_DEFAULT),$student_no,$class]);flash('success','Registration successful. You can now sign in.');redirect('login.php');}
 catch(PDOException $e){flash('error','That email or student number is already registered.');redirect('register.php');}
}
$page_title='Student Registration';$base_path='';require 'includes/header.php';?>
<div class="auth-wrap"><div class="panel"><h2>Student Registration</h2><form method="post"><label>Full name</label><input name="name" required><label>Email</label><input type="email" name="email" required><div class="form-row"><div><label>Student number</label><input name="student_no" required></div><div><label>Class</label><input name="class" required></div></div><label>Password (minimum 6 characters)</label><input type="password" name="password" minlength="6" required><button class="btn" style="margin-top:18px;width:100%">Create account</button></form></div></div>
<?php require 'includes/footer.php';?>