<?php require_once __DIR__ . '/../config.php'; ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= isset($page_title) ? e($page_title).' | ' : '' ?>NYONDO SS Library Management System</title>
<link rel="stylesheet" href="<?= isset($base_path) ? e($base_path) : '' ?>assets/style.css">
</head><body>
<header class="site-header">
  <a class="brand" href="<?= isset($base_path) ? e($base_path) : '' ?>index.php">
    <div class="crest">N<span>SS</span></div>
    <span>NYONDO SS <small>Library Management System</small></span>
  </a>
  <nav>
    <a href="<?= isset($base_path) ? e($base_path) : '' ?>index.php">Home</a>
    <a href="<?= isset($base_path) ? e($base_path) : '' ?>about.php">About Us</a>
    <?php if (!empty($_SESSION['user_id'])): ?>
      <?php if (($_SESSION['role'] ?? '') === 'admin'): ?><a href="<?= isset($base_path) ? e($base_path) : '' ?>admin/dashboard.php">Dashboard</a>
      <?php else: ?><a href="<?= isset($base_path) ? e($base_path) : '' ?>student/dashboard.php">My Account</a><?php endif; ?>
      <a href="<?= isset($base_path) ? e($base_path) : '' ?>logout.php">Logout</a>
    <?php else: ?>
      <a href="<?= isset($base_path) ? e($base_path) : '' ?>login.php">User Login</a>
      <a href="<?= isset($base_path) ? e($base_path) : '' ?>login.php?role=admin">Admin Login</a>
    <?php endif; ?>
  </nav>
</header>
<main class="container">
<?php show_flash(); ?>
