</main>
<footer class="footer">© <?= date('Y') ?> NYONDO SS Library Management System · Read, learn and succeed.</footer>
<script src="<?= isset($base_path) ? e($base_path) : '' ?>assets/app.js"></script>
</body></html>
